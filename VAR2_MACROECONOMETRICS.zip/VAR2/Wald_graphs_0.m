% Plot them both
dates = raw_data.DATE(2:end);
figure('visible', visible);
plot(dates, spread(2:end));  
xlabel('Date');
ylabel('Spread (in%)');
title('Spread between long and short period rates');
file_path = fullfile(pwd, 'figures', 'spread_plot.png');
grid on;
saveas(gcf, file_path);

figure('visible', visible);
plot(dates, gdp_gr);  
xlabel('Date');
ylabel('GDP growth (in %)');
title('Growth rate of Gross Domestic Product');
file_path = fullfile(pwd, 'figures', 'gdp_plot.png');
grid on;
saveas(gcf, file_path);
