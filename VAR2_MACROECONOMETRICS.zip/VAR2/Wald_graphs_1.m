spread_to_spread = reshape(C(1, 1, :), 1, J);
spread_to_gdp = reshape(C(1, 2, :), 1, J);
gdp_to_spread = reshape(C(2, 1, :), 1, J);
gdp_to_gdp = reshape(C(2, 2, :), 1, J);

figure('visible', visible);
plot(1:J, spread_to_spread);
title('Wald coefficient: Spread to Spread');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_spr_spr.png');
grid on;
saveas(gcf, file_path);

figure('visible', visible);
plot(1:J, spread_to_gdp);
title('Wald coefficient: Spread to GDP');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_spr_gdp.png');
grid on;
saveas(gcf, file_path);

figure('visible', visible);
plot(1:J, gdp_to_spread);
title('Wald coefficient: GDP to Spread');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_gdp_spr.png');
grid on;
saveas(gcf, file_path);

figure('visible', visible);
plot(1:J, gdp_to_gdp);
title('Wald coefficient: GDP to GDP');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_gdp_gdp.png');
grid on;
saveas(gcf, file_path);

