
IRF_comp = reshape(IRF(1,1,:), 1, J);
upper_comp = reshape(upper(1,1,:), 1, J);
lower_comp = reshape(lower(1,1,:), 1, J);
figure('visible', visible);
plot(1:J, IRF_comp, 'k', 'LineWidth', 1);
hold on;
plot(1:J, upper_comp,'g--', 'LineWidth', 1.5)
plot(1:J, lower_comp,'g--', 'LineWidth', 1.5)
hold off;
title('IRF coefficient: Spread to Spread');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Boot_IRF_spr_spr.png');
grid on;
saveas(gcf, file_path);

IRF_comp = reshape(IRF(1,2,:), 1, J);
upper_comp = reshape(upper(1,2,:), 1, J);
lower_comp = reshape(lower(1,2,:), 1, J);
figure('visible', visible);
plot(1:J, IRF_comp, 'k', 'LineWidth', 1);
hold on;
plot(1:J, upper_comp,'g--', 'LineWidth', 1.5)
plot(1:J, lower_comp,'g--', 'LineWidth', 1.5)
hold off;
title('IRF coefficient: Spread to GDP');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Boot_IRF_spr_gdp.png');
grid on;
saveas(gcf, file_path);

IRF_comp = reshape(IRF(2,1,:), 1, J);
upper_comp = reshape(upper(2,1,:), 1, J);
lower_comp = reshape(lower(2,1,:), 1, J);
figure('visible', visible);
plot(1:J, IRF_comp, 'k', 'LineWidth', 1);
hold on;
plot(1:J, upper_comp,'g--', 'LineWidth', 1.5)
plot(1:J, lower_comp,'g--', 'LineWidth', 1.5)
hold off;
title('IRF coefficient: GDP to Spread');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Boot_IRF_gdp_spr.png');
grid on;
saveas(gcf, file_path);


IRF_comp = reshape(IRF(2,2,:), 1, J);
upper_comp = reshape(upper(2,2,:), 1, J);
lower_comp = reshape(lower(2,2,:), 1, J);
figure('visible', visible);
plot(1:J, IRF_comp, 'k', 'LineWidth', 1);
hold on;
plot(1:J, upper_comp,'g--', 'LineWidth', 1.5)
plot(1:J, lower_comp,'g--', 'LineWidth', 1.5)
hold off;
title('IRF coefficient: GDP to GDP');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Boot_IRF_gdp_gdp.png');
grid on;
saveas(gcf, file_path);