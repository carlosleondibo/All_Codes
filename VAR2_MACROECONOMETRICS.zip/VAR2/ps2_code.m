%% Load data, remove missing
cd('C:\Users\utente\Dropbox\PC\Documents\GitHub\Macroeconometrics\ps2');
raw_data = readtable('ps2_data.csv');
raw_data = rmmissing(raw_data);

% Uncomment the following to cut out Covid period.
% Result is counterintuitive. Spread is even more sensitive to gdp shocks.
%{
targetDate = datetime('2019-10-01');
raw_data = raw_data(raw_data.DATE < targetDate, :);
%}

%% Initialize variables for spread and gdp growth rate
long_rate = raw_data.GS10;
short_rate = raw_data.FEDFUNDS;
spread = long_rate - short_rate;
gdp = raw_data.GDPC1(1:end);
gdp_gr = diff(log(gdp))*100;
data = [spread(2:end), gdp_gr];
% Figures are not currently shown. Please modify the corresponding script
% if you want to show them
visible = 'off';
run('Wald_graphs_0.m')

%% Estimate Vector Autoregression of order 4 using OLS estimate 
% In particular, we use function written in class
p = 4;
[B, Y, X] = VARestim(data,p);

% From estimated coefficient we retrieve companion form representation
N = size(data,2);
F = [B(2:end,:)'; eye(N*(p-1)) zeros(N*(p-1),N)];
eigenvalues = eig(F);
display(max(abs(eigenvalues)));

%% Since Yt is stable, we can compute Wald decomposition
J = 25;
Fj = eye(N*p);
C = zeros(N,N,J);
C(:,:,1) = eye(N);
for j = 2:J
    Fj = Fj*F;
    C(:,:,j) = Fj(1:N,1:N);
end

%% Now plot series of impulse response function coefficients
run('Wald_graphs_1.m')

%% PART 2 

% Part a: Identify the shocks
[~, ~, ~,res,~,] = WaldVARestim(Y,p,J);
P = [0,1; 1,0];
S = P*(chol(P*cov(res)*P)')*P;
B = zeros(N,N,J);
for j=1:J
    B(:,:,j) = C(:,:,j)*S;
end

%%

[upper, IRF, lower] = VARestimBoot(data,p,100);
visible='on';
run('Wald_graphs_2.m')
visible='off';
%%
VarY=zeros(N,N);
VarDec =zeros(N,N);
for i=1:N
    z = 0;
    for k=1:N
        vyik = 0;
        for j=1:J
            bikj2=B(i,k,j)^2;
            vyik = vyik + bikj2;
        end
        VarY(i,k) =vyik;
        z = z+vyik;
    end
    VarDec(i,:) = VarY(i,:)./z*100; 
end

