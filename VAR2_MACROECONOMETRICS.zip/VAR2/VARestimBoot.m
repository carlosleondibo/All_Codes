function [upper, IRF, lower]=VARestimBoot(data,p,n_samples)
J = 25;
[Beta,Y,X,res, Wald]=WaldVARestim(data,p,J);
[T,N]=size(Y);
F=[Beta(2:end,:)';eye(N*(p-1)) zeros(N*(p-1),N)];
C=[Beta(1,:)'; zeros(N*(p-1),1)];
P = [0,1; 1,0];
S = P*(chol(P*cov(res)*P)')*P;
IRF = Wald;
IRF(:,:,1) = S;
for j=2:J
    IRF(:,:,j) = Wald(:,:,j)*S;
end

% bootstrap
z(:,1)=X(1,2:end)';
BetaBoot = zeros(p*N+1,N,n_samples);
IRFBoot = zeros(N,N,J,n_samples);
for b=1:n_samples 
    IRFBoot(:,:,1,b) = S;
    for t=2:T
        E=[res(randi(T),:)'; zeros(N*(p-1),1)];
        z(:,t)=C+F*z(:,t-1)+E;
    end
    yBoot=[data(1:p,:); z(1:N,:)'];
    [~,~,~,~,Wald] = WaldVARestim(yBoot,p,J);
    for j=2:J
        IRFBoot(:,:,j,b) = Wald(:,:,j)*S;
    end
    [upper, lower] = deal(zeros(N,N,J));
    for i1=1:N
        for i2=1:N
            for j=1:J
                boot_seq = IRFBoot(i1,i2,j,:);
                q = quantile(boot_seq,[0.16, 0.84]);
                upper(i1,i2,j) = q(1,1); lower(i1,i2,j) =q(1,2);
            end
        end
    end
end
