function [Beta, Y, X, res, Wald]=WaldVARestim(y,p,J)
Y = y(p+1:end,:);
[T,N] = size(Y);
X = [ones(T,1)];
for j =1:p
    X = [X y(p+1-j:end-j,:)];
end
Beta = (X'*X)\(X'*Y);
res=Y-X*Beta;
F=[Beta(2:end,:)';eye(N*(p-1)) zeros(N*(p-1),N)];
C=[Beta(1,:)'; zeros(N*(p-1),1)];
Wald = zeros(N,N,J);
Fj = eye(N*p);
for j = 2:J
    Fj = Fj*F;
    Wald(:,:,j) = Fj(1:N,1:N);
end