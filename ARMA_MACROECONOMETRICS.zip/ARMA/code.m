
%%%%%%%%%%%% EXERCISE 1 %%%%%%%%%%%%%%%


%%% We uplouded the GDP data from the CVS
cd('C:\Users\utente\Dropbox\PC\Documents\GitHub\Macroeconometrics') 
GDP = readtable('GDPC1.csv')

% GDP = readtable('GDP.cs)
%% 
%%% Now, we create transfor the data in growth rates, adding a new colum in

%Sort the table by the "Date" column to ensure the data is in chronological order

% Sort the dataset by date
GDP = sortrows(GDP, 'DATE');

% Calculate the growth rates
GDP.GrowthRate = [NaN; diff(GDP.GDPC1) ./ GDP.GDPC1(1:end-1)] * 100;

%% 
%%% a) We plot the series %%%

% Create a time series plot
plot(GDP.DATE, GDP.GrowthRate);

% Add labels and title
xlabel('Date');
ylabel('Growth Rate (%)');
title('GDP Growth Rate Over Time');

%% 
%%% b) Estimate the parameters c and phi with OLS %%%

% Remove the first NaN value
GrowthRate = GDP.GrowthRate;
GrowthRate = GrowthRate(2:end);

% Create a lagged version of the growth rate for AR(1) model
laggedGrowthRate = GrowthRate(1:end-1);

% Define the model matrix
X = [ones(length(laggedGrowthRate), 1), laggedGrowthRate];

% Perform OLS regression to estimate the AR(1) model
[b, bint, r, rint, stats] = regress(GrowthRate(2:end), X);

% Extract estimated parameters
estimated_mean = b(1);
estimated_phi = b(2);

fprintf('Estimated Mean: %f\n', estimated_mean);
fprintf('Estimated Autoregressive Coefficient (phi): %f\n', estimated_phi);;

%% 
%%% c) Estimate and plot the first 1o autocorrelations of the AR %%~


% Define the number of lags
maxLag = 10;

% Calculate the autocorrelation values based on the AR(1) model
autocorrelations = zeros(1, maxLag + 1);
autocorrelations(1) = 1; % Autocorrelation at lag 0 is always 1
for lag = 1:maxLag
    autocorrelations(lag + 1) = estimated_phi ^ lag;
end

% Plot the autocorrelations
figure;
stem(0:maxLag, autocorrelations);
xlabel('Lag');
ylabel('Autocorrelation');
ylim([min(-0.1, min(autocorrelations) - 0.05), max(0.2, 0.1341 + 0.05)]);
title('Autocorrelations Based on AR(1) Model Coefficients');

fprintf('Autocorrelation values for lags 0 to %d:\n', maxLag);
for lag = 0:maxLag
    fprintf('Lag %d: %f\n', lag, autocorrelations(lag + 1));
end
%% 
%%% c) Estimate autocorrelations up to lag 10 (and getting intervals of
%%% confidance %%%
maxLag = 10;
[autocorrelations, lags, ACFBounds] = autocorr(GrowthRate, maxLag);

% Set custom bounds
lowerBound = -0.1145;
upperBound = 0.1145;

% Plot the autocorrelations along with the custom bounds
figure;
stem(lags, autocorrelations);
hold on;
plot(lags, lowerBound * ones(1, maxLag + 1), 'b--', 'DisplayName', 'Custom Lower Bound');
plot(lags, upperBound * ones(1, maxLag + 1), 'b--', 'DisplayName', 'Custom Upper Bound');
xlabel('Lag');
ylabel('Autocorrelation');
ylim([min(-0.1, min(autocorrelations) - 0.05), max(1+ 0.1341 + 0.05)]);
title('Autocorrelations of GDP Growth Rate with Custom Bounds');
legend;

% Display the autocorrelation values and their custom bounds
fprintf('Autocorrelation values for lags 0 to %d:\n', maxLag);
for lag = 0:maxLag
    fprintf('Lag %d: %f ( Lower Bound: %f,  Upper Bound: %f)\n', lag, autocorrelations(lag + 1), lowerBound, upperBound);
end
%% d) Wold decompositionn

% Define the AR(1) process parameters (replace with your estimated values)
 % Autoregressive coefficient

% Define the maximum lag for the coefficients
maxLag = 10;

% Create a unit impulse at lag 0
impulse = [1; zeros(maxLag, 1)];

% Use the filter function to obtain the Wold coefficients
WoldCoefficients = filter(1, [1, -estimated_phi], impulse);

% Plot the Wold coefficients
figure;
stem(0:maxLag, WoldCoefficients);
xlabel('Lag');
ylabel('Wold Coefficient');
ylim([min(-0.1), max(0.2)]);
title('Wold Representation Coefficients for yt (AR(1) Process)');

% Print the Wold coefficients
fprintf('Wold Coefficients for AR(1) Process:\n');
for lag = 0:maxLag
    fprintf('Lag %d: %f\n', lag, WoldCoefficients(lag + 1));
end


%% 
%%%%%%%%%%%% EXERCISE 2 %%%%%%%%%%%%%%%
%%% We estimate the mean c and parameters \phi_1 and \phi_2

% Create lagged versions of the growth rate for AR(2) model
laggedGrowthRate1 = GrowthRate(2:end-1); % Lag 1
laggedGrowthRate2 = GrowthRate(1:end-2); % Lag 2

% Define the model matrix
X = [ones(length(laggedGrowthRate1), 1), laggedGrowthRate1, laggedGrowthRate2];

% Perform OLS regression to estimate the AR(2) model
[b, bint, r, rint, stats] = regress(GrowthRate(3:end), X); % Use GrowthRate(3:end) because you're estimating an AR(2) model

% Extract estimated parameters
estimated_mean = b(1);
estimated_phi1 = b(2);
estimated_phi2 = b(3);

fprintf('Estimated Mean: %f\n', estimated_mean);
fprintf('Estimated Autoregressive Coefficient (phi1): %f\n', estimated_phi1);
fprintf('Estimated Autoregressive Coefficient (phi2): %f\n', estimated_phi2);
%% 
%%%% Calculating the roots of the polynomial associated with the AR(2) %%%

%see that the polynomial is given by \phi(z) = 1 - 1.2z - 0.10L^2 = 0 we can
%use the root function of matlab to compute the roots of that polynomial,

p = [-0.10 -0.12 1]
r = roots(p)

%% 

%% Wold decomposition
% Define the AR(2) process parameters (replace with your estimated values)

% Define the maximum lag for the coefficients
maxLag = 10;

% Create a unit impulse at lag 0
impulse = [1; zeros(maxLag, 1)];

% Use the filter function to obtain the Wold coefficients for the AR(2) process
AR2Coefficients = [1, -estimated_phi1, -estimated_phi2];

% Truncate the series expansion for psi_j to a finite value N. 
format long;
N = 10;
psi = zeros(1, N);
for j = 1:N
    psij = 0;
    for h = 0:floor(j/2)
        psij = psij + nchoosek(j - h, h) * estimated_phi1^(j - 2*h) * estimated_phi2^h;
    end
    psi(j) = psij;
end
% Just check that gives the same as built in. It does

WoldCoefficients = [1,psi];
% WoldCoefficients = filter(1, AR2Coefficients, impulse);

% Plot the Wold coefficients
figure;
stem(0:maxLag, WoldCoefficients);
xlabel('Lag');
ylabel('Wold Coefficient');
ylim([min(-0.1), max(0.2)]);
title('Wold Representation Coefficients for yt (AR(2) Process)');

% Print the Wold coefficients
fprintf('Wold Representation Coefficients for AR(2) Process:\n');
for lag = 0:maxLag
    fprintf('Lag %d: %f\n', lag, WoldCoefficients(lag + 1));
end