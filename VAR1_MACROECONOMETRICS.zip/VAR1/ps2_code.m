%% Load data, remove missing
cd('C:\Users\utente\Dropbox\PC\Documents\GitHub\Macroeconometrics\ps2');
raw_data = readtable('ps2_data.csv');
raw_data = rmmissing(raw_data);

% Uncomment the following to cut out Covid period.
% Result is counterintuitive. Spread is even more sensitive to gdp shocks.
%{
targetDate = datetime('2019-10-01');
raw_data = raw_data(raw_data.DATE < targetDate, :);
%}

%% Initialize variables for spread and gdp growth rate
long_rate = raw_data.GS10;
short_rate = raw_data.FEDFUNDS;
spread = long_rate - short_rate;
gdp = raw_data.GDPC1(1:end);
gdp_gr = diff(log(gdp))*100;
data = [spread(2:end), gdp_gr];

% Plot them both
dates = raw_data.DATE(2:end);
figure;
plot(dates, spread(2:end));  
xlabel('Date');
ylabel('Spread (in%)');
title('Spread between long and short period rates');
file_path = fullfile(pwd, 'figures', 'spread_plot.png');
grid on;
saveas(gcf, file_path);

figure;
plot(dates, gdp_gr);  
xlabel('Date');
ylabel('GDP growth (in %)');
title('Growth rate of Gross Domestic Product');
file_path = fullfile(pwd, 'figures', 'gdp_plot.png');
grid on;
saveas(gcf, file_path);

%% Estimate Vector Autoregression of order 4 using OLS estimate 
% In particular, we use function written in class
p = 4;
[B, Y, X] = VARestim(data,p);

% From estimated coefficient we retrieve companion form representation
n = size(data,2);
F = [B(2:end,:)'; eye(n*(p-1)) zeros(n*(p-1),n)];
eigenvalues = eig(F);
display(max(abs(eigenvalues)));

%% Since Yt is stable, we can compute Wald decomposition
J = 25;
Fj = eye(n*p);
C = zeros(n,n,J);
C(:,:,1) = eye(n);
for j = 2:J
    Fj = Fj*F;
    C(:,:,j) = Fj(1:n,1:n);
end

%% Now plot series of impulse response function coefficients
spread_to_spread = reshape(C(1, 1, :), 1, J);
spread_to_gdp = reshape(C(1, 2, :), 1, J);
gdp_to_spread = reshape(C(2, 1, :), 1, J);
gdp_to_gdp = reshape(C(2, 2, :), 1, J);

figure;
plot(1:J, spread_to_spread);
title('Wald coefficient: Spread to Spread');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_spr_spr.png');
grid on;
saveas(gcf, file_path);


figure;
plot(1:J, spread_to_gdp);
title('Wald coefficient: Spread to GDP');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_spr_gdp.png');
grid on;
saveas(gcf, file_path);


figure;
plot(1:J, gdp_to_spread);
title('Wald coefficient: GDP to Spread');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_gdp_spr.png');
grid on;
saveas(gcf, file_path);

figure;
plot(1:J, gdp_to_gdp);
title('Wald coefficient: GDP to GDP');
xlabel('Periods');
ylabel('Estimates response to impulse');
file_path = fullfile(pwd, 'figures', 'Wald_VAR_gdp_gdp.png');
grid on;
saveas(gcf, file_path);
